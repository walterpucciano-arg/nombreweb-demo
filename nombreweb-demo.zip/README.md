# NombreWeb demo

Demo visual React/Vite de la plataforma +18.

## Para subir a Vercel
1. Subí estos archivos a un repositorio de GitHub.
2. En Vercel: Add New > Project > Import Git Repository.
3. Framework: Vite.
4. Build Command: npm run build.
5. Output Directory: dist.
6. Deploy.

Esta es una maqueta visual. Registro, login, chat real, pagos y base de datos se conectan en la siguiente etapa con Supabase.
