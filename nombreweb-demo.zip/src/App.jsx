import React, { useMemo, useState } from "react";

const profiles = [
  { id: 1, name: "Sofía", age: 29, province: "Buenos Aires", city: "San Nicolás", online: true, verified: true, premium: true, interests: ["Charlar", "Encuentros", "Discreción"], bio: "Buena onda, química real y ver qué surge.", image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80" },
  { id: 2, name: "Mauro", age: 34, province: "Santa Fe", city: "Rosario", online: true, verified: false, premium: false, interests: ["Nuevas experiencias", "Chat", "Cerca"], bio: "Sin vueltas, con respeto y buena energía.", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=900&q=80" },
  { id: 3, name: "Valen", age: 27, province: "Córdoba", city: "Córdoba Capital", online: false, verified: true, premium: false, interests: ["Conexión", "Salidas", "Libre"], bio: "Me gusta conocer gente sin prejuicios.", image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=900&q=80" },
  { id: 4, name: "Nico", age: 31, province: "Buenos Aires", city: "CABA", online: true, verified: true, premium: true, interests: ["Experiencias", "Noches", "Chat"], bio: "Planes simples, buena charla y respeto.", image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=900&q=80" },
  { id: 5, name: "Luna", age: 36, province: "Mendoza", city: "Mendoza", online: false, verified: false, premium: true, interests: ["Privado", "Afinidad", "Charlas"], bio: "Busco gente con buena vibra y cero drama.", image: "https://images.unsplash.com/photo-1502823403499-6ccfcf4fb453?auto=format&fit=crop&w=900&q=80" },
  { id: 6, name: "Ema", age: 25, province: "Buenos Aires", city: "Mar del Plata", online: true, verified: true, premium: false, interests: ["Online", "Encuentros", "Curiosidad"], bio: "Charla primero, después vemos.", image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=900&q=80" },
];

const chatMessages = [
  { user: "Sala Buenos Aires", text: "38 personas conectadas ahora" },
  { user: "Sofía", text: "¿Quién anda por San Nicolás?" },
  { user: "Rosario +18", text: "Nueva sala activa esta noche" },
  { user: "Moderación", text: "Recordá respetar las reglas de la comunidad" },
];

const provinces = ["Todas", "Buenos Aires", "Santa Fe", "Córdoba", "Mendoza"];

export default function AdultSocialPrototype() {
  const [province, setProvince] = useState("Todas");
  const [onlyOnline, setOnlyOnline] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeScreen, setActiveScreen] = useState("home");

  const filteredProfiles = useMemo(() => {
    return profiles.filter((profile) => {
      const provinceMatch = province === "Todas" || profile.province === province;
      const onlineMatch = !onlyOnline || profile.online;
      return provinceMatch && onlineMatch;
    });
  }, [province, onlyOnline]);

  return (
    <div className="min-h-screen bg-[#07070b] text-white">
      <BackgroundGlow />

      <header className="relative z-20 sticky top-0 border-b border-white/10 bg-black/35 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-6">
          <button onClick={() => setActiveScreen("home")} className="flex items-center gap-3 text-left">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-fuchsia-500 to-violet-700 shadow-lg shadow-fuchsia-900/30">🔥</div>
            <div>
              <p className="text-xl font-black tracking-tight">NombreWeb</p>
              <p className="text-xs text-white/50">Comunidad +18 Argentina</p>
            </div>
          </button>

          <nav className="hidden items-center gap-2 text-sm text-white/70 md:flex">
            <NavButton active={activeScreen === "home"} onClick={() => setActiveScreen("home")}>Inicio</NavButton>
            <NavButton active={activeScreen === "app"} onClick={() => setActiveScreen("app")}>Explorar</NavButton>
            <NavButton active={activeScreen === "register"} onClick={() => setActiveScreen("register")}>Registro +18</NavButton>
            <NavButton active={activeScreen === "messages"} onClick={() => setActiveScreen("messages")}>Mensajes</NavButton>
            <NavButton active={activeScreen === "webcam"} onClick={() => setActiveScreen("webcam")}>Live</NavButton>
            <NavButton active={activeScreen === "admin"} onClick={() => setActiveScreen("admin")}>Admin</NavButton>
            <NavButton active={activeScreen === "profile"} onClick={() => setActiveScreen("profile")}>Mi perfil</NavButton>
          </nav>

          <div className="hidden items-center gap-3 md:flex">
            <button onClick={() => setActiveScreen("app")} className="rounded-full px-4 py-2 text-sm text-white/75 hover:bg-white/10">Ingresar</button>
            <button onClick={() => setActiveScreen("register")} className="rounded-full bg-white px-5 py-2 text-sm font-bold text-black hover:bg-white/90">Crear cuenta gratis</button>
          </div>

          <button className="md:hidden" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? "✕" : "☰"}</button>
        </div>

        {menuOpen && (
          <div className="border-t border-white/10 bg-black/90 px-4 py-4 md:hidden">
            <div className="grid gap-2 text-sm text-white/80">
              <MobileNav setActiveScreen={setActiveScreen} name="Inicio" screen="home" />
              <MobileNav setActiveScreen={setActiveScreen} name="Explorar" screen="app" />
              <MobileNav setActiveScreen={setActiveScreen} name="Registro +18" screen="register" />
              <MobileNav setActiveScreen={setActiveScreen} name="Mensajes" screen="messages" />
              <MobileNav setActiveScreen={setActiveScreen} name="Live" screen="webcam" />
              <MobileNav setActiveScreen={setActiveScreen} name="Admin" screen="admin" />
              <MobileNav setActiveScreen={setActiveScreen} name="Mi perfil" screen="profile" />
            </div>
          </div>
        )}
      </header>

      <main className="relative z-10">
        {activeScreen === "home" && <HomeScreen setActiveScreen={setActiveScreen} />}
        {activeScreen === "register" && <RegisterScreen setActiveScreen={setActiveScreen} />}
        {activeScreen === "app" && <AppScreen province={province} setProvince={setProvince} onlyOnline={onlyOnline} setOnlyOnline={setOnlyOnline} filteredProfiles={filteredProfiles} setActiveScreen={setActiveScreen} />}
        {activeScreen === "messages" && <MessagesScreen />}
        {activeScreen === "webcam" && <WebcamScreen />}
        {activeScreen === "admin" && <AdminScreen />}
        {activeScreen === "profile" && <MyProfileScreen />}
      </main>

      <footer className="relative z-10 border-t border-white/10 px-4 py-8 text-center text-sm text-white/45">
        <p>NombreWeb · Comunidad +18 · Argentina</p>
        <p className="mt-2">Términos · Privacidad · Reglas de comunidad · Contacto</p>
      </footer>
    </div>
  );
}

function BackgroundGlow() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      <div className="absolute -top-32 -left-28 h-96 w-96 rounded-full bg-fuchsia-600/20 blur-3xl" />
      <div className="absolute top-20 right-0 h-[28rem] w-[28rem] rounded-full bg-violet-700/20 blur-3xl" />
      <div className="absolute bottom-0 left-1/3 h-96 w-96 rounded-full bg-blue-600/10 blur-3xl" />
    </div>
  );
}

function MobileNav({ setActiveScreen, name, screen }) {
  return <button onClick={() => setActiveScreen(screen)} className="rounded-xl px-3 py-2 text-left hover:bg-white/10">{name}</button>;
}

function NavButton({ children, active, onClick }) {
  return <button onClick={onClick} className={`rounded-full px-4 py-2 transition ${active ? "bg-white text-black" : "hover:bg-white/10 hover:text-white"}`}>{children}</button>;
}

function HomeScreen({ setActiveScreen }) {
  return (
    <>
      <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-12 md:grid-cols-[1.05fr_.95fr] md:px-6 md:py-20">
        <div>
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-fuchsia-400/30 bg-fuchsia-400/10 px-4 py-2 text-sm text-fuchsia-100">🔒 Solo para mayores de 18 años</div>
          <h1 className="max-w-3xl text-4xl font-black leading-tight tracking-tight md:text-6xl">Conocé personas reales y viví nuevas experiencias.</h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-white/65 md:text-lg">Una red social adulta para charlar, conectar y encontrar personas cerca tuyo. Perfiles, filtros por ciudad, chat general y mensajes privados en una experiencia moderna y segura.</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <button onClick={() => setActiveScreen("register")} className="rounded-full bg-gradient-to-r from-fuchsia-500 to-violet-700 px-7 py-4 font-bold shadow-xl shadow-fuchsia-950/40 hover:opacity-95">Crear cuenta gratis</button>
            <button onClick={() => setActiveScreen("app")} className="rounded-full border border-white/15 bg-white/5 px-7 py-4 font-bold text-white/85 hover:bg-white/10">Ver personas online</button>
          </div>
          <div className="mt-8 grid max-w-xl grid-cols-3 gap-3">
            <Stat number="+18" label="Comunidad adulta" />
            <Stat number="24/7" label="Chat activo" />
            <Stat number="AR" label="Argentina primero" />
          </div>
        </div>

        <div className="relative">
          <div className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-4 shadow-2xl backdrop-blur-xl">
            <div className="mb-4 flex items-center justify-between">
              <div><p className="text-sm text-white/45">Online ahora</p><p className="font-bold">Personas cerca tuyo</p></div>
              <div className="flex items-center gap-2 rounded-full bg-emerald-400/10 px-3 py-1 text-xs text-emerald-300">🟢 En vivo</div>
            </div>
            <div className="grid grid-cols-2 gap-3">{profiles.slice(0, 4).map((profile) => <ProfileMini key={profile.id} profile={profile} />)}</div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-8 md:px-6">
        <div className="grid gap-5 md:grid-cols-3">
          <SecurityCard icon="🛡️" title="Moderación" text="Denuncias, bloqueo de usuarios y revisión desde panel administrador." />
          <SecurityCard icon="🔒" title="Privacidad" text="Configuración de perfil, contenido y visibilidad para cada usuario." />
          <SecurityCard icon="🔔" title="Reglas claras" text="Comunidad +18 con normas estrictas contra contenido ilegal, spam y acoso." />
        </div>
      </section>
    </>
  );
}

function RegisterScreen({ setActiveScreen }) {
  return (
    <section className="mx-auto grid max-w-7xl gap-8 px-4 py-10 md:grid-cols-[.95fr_1.05fr] md:px-6 md:py-16">
      <div className="rounded-[2rem] border border-white/10 bg-white/[0.05] p-6 md:p-8">
        <div className="mb-5 inline-flex rounded-2xl bg-fuchsia-500/15 p-3 text-fuchsia-200">👤</div>
        <h2 className="text-3xl font-black md:text-4xl">Crear cuenta +18</h2>
        <p className="mt-4 leading-7 text-white/60">Esta pantalla sería el primer filtro serio de la plataforma. Antes de entrar, cada usuario debe declarar que es mayor de edad y aceptar las reglas de la comunidad.</p>
        <div className="mt-6 grid gap-3 text-sm text-white/70">
          <InfoRow icon="🔒" text="Acceso exclusivo para mayores de 18 años." />
          <InfoRow icon="🛡️" text="Denuncias, bloqueos y moderación activa." />
          <InfoRow icon="🚩" text="Prohibido contenido ilegal, terceros sin consentimiento, spam o acoso." />
        </div>
      </div>

      <div className="rounded-[2rem] border border-white/10 bg-black/35 p-6 shadow-2xl backdrop-blur-xl md:p-8">
        <div className="grid gap-4">
          <Field label="Alias o nombre visible" placeholder="Ej: Alex" />
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Email" placeholder="tuemail@email.com" />
            <Field label="Contraseña" placeholder="Mínimo 8 caracteres" type="password" />
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            <Field label="Edad" placeholder="Ej: 29" />
            <SelectField label="Provincia" options={["Buenos Aires", "Santa Fe", "Córdoba", "Mendoza"]} />
            <Field label="Ciudad" placeholder="Ej: San Nicolás" />
          </div>
          <SelectField label="Busco" options={["Charlar", "Encuentros", "Nuevas experiencias", "Parejas", "Discreción"]} />
          <label className="flex gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm text-white/70">
            <input type="checkbox" className="mt-1" /> Declaro que soy mayor de 18 años y acepto los términos, reglas de comunidad y política de privacidad.
          </label>
          <button onClick={() => setActiveScreen("app")} className="rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-700 px-5 py-4 font-black">Crear cuenta y entrar</button>
          <button onClick={() => setActiveScreen("app")} className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-5 py-4 font-bold text-white/80">➡️ Ya tengo cuenta</button>
        </div>
      </div>
    </section>
  );
}

function AppScreen({ province, setProvince, onlyOnline, setOnlyOnline, filteredProfiles, setActiveScreen }) {
  return (
    <section className="mx-auto grid max-w-7xl gap-6 px-4 py-8 md:grid-cols-[260px_1fr_330px] md:px-6">
      <aside className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-5 h-fit">
        <h3 className="flex items-center gap-2 text-lg font-black">⚙️ Filtros</h3>
        <div className="mt-5 grid gap-4">
          <SelectField label="Provincia" value={province} onChange={(e) => setProvince(e.target.value)} options={provinces} />
          <Field label="Ciudad" placeholder="Ej: Rosario" />
          <div>
            <label className="text-sm font-bold text-white/70">Edad</label>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <input className="rounded-2xl border border-white/10 bg-black/40 px-3 py-3 outline-none" placeholder="18" />
              <input className="rounded-2xl border border-white/10 bg-black/40 px-3 py-3 outline-none" placeholder="45" />
            </div>
          </div>
          <button onClick={() => setOnlyOnline(!onlyOnline)} className={`rounded-2xl px-4 py-3 text-sm font-bold ${onlyOnline ? "bg-emerald-500 text-black" : "bg-white/10 text-white"}`}>Solo online ahora</button>
          <button className="rounded-2xl bg-white px-4 py-3 text-sm font-bold text-black">Aplicar filtros</button>
        </div>
      </aside>

      <div>
        <div className="mb-5 flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.25em] text-fuchsia-300">Panel interno</p>
            <h2 className="mt-2 text-3xl font-black">Explorar perfiles</h2>
            <p className="mt-2 text-white/55">Mensajes libres, filtros por ubicación y perfiles online.</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setActiveScreen("messages")} className="rounded-full border border-white/10 bg-white/[0.06] px-5 py-3 font-bold hover:bg-white/10">Abrir mensajes</button>
            <button onClick={() => setActiveScreen("profile")} className="rounded-full border border-white/10 bg-white/[0.06] px-5 py-3 font-bold hover:bg-white/10">Editar mi perfil</button>
          </div>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-2">{filteredProfiles.map((profile) => <ProfileCard key={profile.id} profile={profile} />)}</div>
      </div>

      <aside className="grid gap-5 h-fit">
        <ChatBox />
        <PremiumBox />
      </aside>
    </section>
  );
}

function MyProfileScreen() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-8 md:px-6">
      <div className="grid gap-6 lg:grid-cols-[.9fr_1.1fr]">
        <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.05]">
          <div className="relative h-[420px]">
            <img src={profiles[0].image} alt="Mi perfil" className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <div className="mb-3 flex gap-2">
                <span className="rounded-full bg-emerald-400 px-3 py-1 text-xs font-bold text-black">Online</span>
                <span className="rounded-full bg-yellow-300 px-3 py-1 text-xs font-bold text-black">Premium demo</span>
              </div>
              <h2 className="text-4xl font-black">Tu perfil, 29</h2>
              <p className="mt-2 flex items-center gap-2 text-white/70">📍 San Nicolás, Buenos Aires</p>
            </div>
          </div>
          <div className="p-6">
            <p className="leading-7 text-white/65">Acá el usuario edita cómo quiere mostrarse, qué busca, su ciudad, sus fotos, videos y privacidad.</p>
            <div className="mt-5 flex flex-wrap gap-2">{profiles[0].interests.map((i) => <span key={i} className="rounded-full bg-white/10 px-3 py-1 text-xs">{i}</span>)}</div>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <ActionButton icon="🚫" text="Bloqueados" />
              <ActionButton icon="🚩" text="Denuncias" />
            </div>
          </div>
        </div>

        <div className="grid gap-5">
          <div className="rounded-[2rem] border border-white/10 bg-black/35 p-6">
            <h3 className="text-2xl font-black">Editar datos</h3>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <Field label="Alias" placeholder="Tu alias" />
              <Field label="Edad" placeholder="29" />
              <SelectField label="Provincia" options={["Buenos Aires", "Santa Fe", "Córdoba", "Mendoza"]} />
              <Field label="Ciudad" placeholder="San Nicolás" />
            </div>
            <div className="mt-4">
              <label className="text-sm font-bold text-white/70">Descripción</label>
              <textarea className="mt-2 min-h-28 w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 outline-none" placeholder="Contá qué buscás..." />
            </div>
            <button className="mt-5 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-700 px-5 py-4 font-black">Guardar cambios</button>
          </div>

          <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6">
            <h3 className="text-2xl font-black">Fotos y videos</h3>
            <p className="mt-2 text-sm text-white/55">Zona de subida de contenido. En la versión real debería tener revisión, denuncias y reglas claras.</p>
            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              <UploadCard icon="📸" text="Subir foto" />
              <UploadCard icon="🎥" text="Subir video" />
              <UploadCard icon="🖼️" text="Galería" />
            </div>
          </div>

          <div className="rounded-[2rem] border border-fuchsia-400/20 bg-fuchsia-500/10 p-6">
            <h3 className="text-xl font-black">Privacidad y seguridad</h3>
            <div className="mt-4 grid gap-3 text-sm text-white/70">
              <label className="flex gap-3"><input type="checkbox" /> Mostrar mi perfil en búsquedas.</label>
              <label className="flex gap-3"><input type="checkbox" /> Permitir mensajes de cualquier usuario.</label>
              <label className="flex gap-3"><input type="checkbox" /> Mostrar cuando estoy online.</label>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ChatBox() {
  return (
    <div className="rounded-[2rem] border border-white/10 bg-black/30 p-5 backdrop-blur-xl">
      <div className="mb-5 flex items-center justify-between">
        <div><h3 className="text-xl font-black">Chat general</h3><p className="text-sm text-white/55">Vista previa de actividad.</p></div>💬
      </div>
      <div className="grid gap-3">{chatMessages.map((message, index) => <div key={index} className="rounded-2xl bg-white/[0.06] p-4"><p className="text-sm font-bold text-fuchsia-200">{message.user}</p><p className="mt-1 text-sm text-white/75">{message.text}</p></div>)}</div>
      <div className="mt-5 flex gap-3">
        <input placeholder="Mensaje..." className="min-w-0 flex-1 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 outline-none placeholder:text-white/35" />
        <button className="rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-700 px-4 font-bold">Enviar</button>
      </div>
    </div>
  );
}

function MessagesScreen() {
  const conversations = [
    { name: "Sofía", city: "San Nicolás", last: "¿Seguís conectado?", online: true, image: profiles[0].image },
    { name: "Nico", city: "CABA", last: "Hablamos más tarde 😉", online: true, image: profiles[3].image },
    { name: "Luna", city: "Mendoza", last: "Me gustó tu perfil", online: false, image: profiles[4].image },
  ];

  return (
    <section className="mx-auto max-w-7xl px-4 py-8 md:px-6">
      <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
        <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-5">
          <div className="mb-5 flex items-center justify-between">
            <div><p className="text-sm uppercase tracking-[0.2em] text-fuchsia-300">Mensajes</p><h2 className="text-2xl font-black">Chats privados</h2></div>
            <span className="rounded-full bg-fuchsia-500/20 px-3 py-1 text-xs font-bold text-fuchsia-200">3 nuevos</span>
          </div>
          <div className="grid gap-3">
            {conversations.map((chat) => (
              <button key={chat.name} className="flex items-center gap-4 rounded-2xl border border-white/10 bg-black/30 p-3 text-left hover:bg-white/[0.05]">
                <div className="relative">
                  <img src={chat.image} alt={chat.name} className="h-14 w-14 rounded-2xl object-cover" />
                  {chat.online && <span className="absolute -bottom-1 -right-1 h-4 w-4 rounded-full border-2 border-[#07070b] bg-emerald-400" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2"><p className="truncate font-bold">{chat.name}</p><span className="text-xs text-white/35">22:14</span></div>
                  <p className="truncate text-sm text-white/45">{chat.last}</p>
                  <p className="mt-1 text-xs text-fuchsia-200">📍 {chat.city}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex min-h-[620px] flex-col rounded-[2rem] border border-white/10 bg-black/35 backdrop-blur-xl">
          <div className="flex items-center justify-between border-b border-white/10 p-5">
            <div className="flex items-center gap-4">
              <img src={profiles[0].image} alt="Sofía" className="h-14 w-14 rounded-2xl object-cover" />
              <div><h3 className="text-xl font-black">Sofía</h3><p className="text-sm text-emerald-300">🟢 Online ahora</p></div>
            </div>
            <div className="flex gap-2"><button className="rounded-2xl bg-white/10 px-4 py-3 hover:bg-white/15">📹</button><button className="rounded-2xl bg-white/10 px-4 py-3 hover:bg-white/15">🚩</button></div>
          </div>
          <div className="flex-1 space-y-4 overflow-y-auto p-5">
            <div className="max-w-[75%] rounded-3xl rounded-bl-md bg-white/10 px-5 py-4 text-white/80">Hola 😊 ¿Cómo estás?</div>
            <div className="ml-auto max-w-[75%] rounded-3xl rounded-br-md bg-gradient-to-r from-fuchsia-500 to-violet-700 px-5 py-4 text-white">Todo bien! Recién entrando un rato 😄</div>
            <div className="max-w-[75%] rounded-3xl rounded-bl-md bg-white/10 px-5 py-4 text-white/80">Vi que sos de San Nicolás también.</div>
          </div>
          <div className="border-t border-white/10 p-5">
            <div className="flex gap-3">
              <input placeholder="Escribí un mensaje..." className="min-w-0 flex-1 rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-4 outline-none placeholder:text-white/35" />
              <button className="rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-700 px-6 font-bold">Enviar</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function WebcamScreen() {
  const liveUsers = profiles.filter((p) => p.online);
  return (
    <section className="mx-auto max-w-7xl px-4 py-8 md:px-6">
      <div className="mb-8 flex items-center justify-between">
        <div><p className="text-sm font-bold uppercase tracking-[0.25em] text-fuchsia-300">Live</p><h2 className="mt-2 text-4xl font-black">Webcams en vivo</h2><p className="mt-2 text-white/55">Usuarios transmitiendo ahora mismo.</p></div>
        <button className="rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-700 px-6 py-4 font-black">🔴 Iniciar transmisión</button>
      </div>
      <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">
        {liveUsers.map((profile) => (
          <div key={profile.id} className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.05]">
            <div className="relative">
              <img src={profile.image} alt={profile.name} className="h-[340px] w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
              <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full bg-red-500 px-3 py-1 text-xs font-bold text-white">🔴 EN VIVO</div>
              <div className="absolute right-4 top-4 rounded-full bg-black/50 px-3 py-1 text-xs text-white">👁️ 248</div>
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center justify-between">
                  <div><h3 className="text-2xl font-black">{profile.name}</h3><p className="mt-1 text-sm text-white/70">📍 {profile.city}</p></div>
                  <button className="rounded-full bg-white px-4 py-2 text-sm font-black text-black">Ver live</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function AdminScreen() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-8 md:px-6">
      <div className="mb-8 flex items-center justify-between">
        <div><p className="text-sm font-bold uppercase tracking-[0.25em] text-fuchsia-300">Administrador</p><h2 className="mt-2 text-4xl font-black">Panel de control</h2><p className="mt-2 text-white/55">Moderación, usuarios y estadísticas.</p></div>
        <button className="rounded-2xl bg-red-500 px-6 py-4 font-black">🚫 Banear usuario</button>
      </div>

      <div className="grid gap-5 md:grid-cols-4">
        <Stat number="14.281" label="Usuarios" />
        <Stat number="2.304" label="Online" />
        <Stat number="482" label="Premium" />
        <Stat number="17" label="Reportes" />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.1fr_.9fr]">
        <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6">
          <h3 className="text-2xl font-black">Últimos reportes</h3>
          <div className="mt-5 grid gap-4">
            {["Posible perfil falso", "Spam en mensajes privados", "Contenido inapropiado", "Usuario denunciado múltiples veces"].map((report) => (
              <div key={report} className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/30 p-4">
                <div><p className="font-bold">{report}</p><p className="mt-1 text-sm text-white/45">Hace 5 minutos</p></div>
                <button className="rounded-full bg-white/10 px-4 py-2 text-sm font-bold hover:bg-white/15">Revisar</button>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-[2rem] border border-white/10 bg-black/35 p-6">
          <h3 className="text-2xl font-black">Moderación rápida</h3>
          <div className="mt-5 grid gap-4">
            <button className="rounded-2xl bg-white/10 px-5 py-4 text-left font-bold hover:bg-white/15">🚫 Suspender cuenta</button>
            <button className="rounded-2xl bg-white/10 px-5 py-4 text-left font-bold hover:bg-white/15">🗑️ Eliminar contenido</button>
            <button className="rounded-2xl bg-white/10 px-5 py-4 text-left font-bold hover:bg-white/15">⭐ Activar premium</button>
            <button className="rounded-2xl bg-white/10 px-5 py-4 text-left font-bold hover:bg-white/15">🛡️ Verificaciones</button>
          </div>
        </div>
      </div>
    </section>
  );
}

function PremiumBox() {
  return (
    <div className="rounded-[2rem] border border-fuchsia-400/20 bg-gradient-to-br from-white/[0.08] to-fuchsia-500/10 p-5">
      <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-yellow-400/10 px-4 py-2 text-sm text-yellow-200">👑 Plan Premium</div>
      <h3 className="text-xl font-black">Más visibilidad, mensajes y webcam.</h3>
      <div className="mt-4 grid gap-3">
        <PremiumItem icon="💬" text="Mensajes ilimitados" />
        <PremiumItem icon="⭐" text="Perfil destacado" />
        <PremiumItem icon="👁️" text="Ver visitantes" />
        <PremiumItem icon="📹" text="Acceso a webcam/live" />
      </div>
      <button className="mt-5 w-full rounded-2xl bg-white px-5 py-4 font-black text-black">Ver planes</button>
    </div>
  );
}

function Stat({ number, label }) {
  return <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4"><p className="text-xl font-black">{number}</p><p className="mt-1 text-xs text-white/45">{label}</p></div>;
}

function Field({ label, placeholder, type = "text" }) {
  return <div className="grid gap-2"><label className="text-sm font-bold text-white/70">{label}</label><input type={type} className="rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 outline-none placeholder:text-white/30" placeholder={placeholder} /></div>;
}

function SelectField({ label, options, value, onChange }) {
  return <div className="grid gap-2"><label className="text-sm font-bold text-white/70">{label}</label><select value={value} onChange={onChange} className="rounded-2xl border border-white/10 bg-black/50 px-4 py-3 outline-none">{options.map((option) => <option key={option}>{option}</option>)}</select></div>;
}

function InfoRow({ icon, text }) {
  return <div className="flex items-center gap-3 rounded-2xl bg-white/[0.05] p-4"><span className="text-fuchsia-200">{icon}</span><span>{text}</span></div>;
}

function ProfileMini({ profile }) {
  return (
    <div className="relative overflow-hidden rounded-[1.5rem] bg-white/10">
      <img src={profile.image} alt={profile.name} className="h-44 w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-transparent" />
      <div className="absolute bottom-3 left-3 right-3">
        <div className="flex items-center justify-between"><p className="font-bold">{profile.name}, {profile.age}</p>{profile.online && <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />}</div>
        <p className="mt-1 flex items-center gap-1 text-xs text-white/70">📍 {profile.city}</p>
      </div>
    </div>
  );
}

function ProfileCard({ profile }) {
  return (
    <article className="group overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.05] shadow-xl shadow-black/20 backdrop-blur">
      <div className="relative">
        <img src={profile.image} alt={profile.name} className="h-80 w-full object-cover transition duration-500 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/15 to-transparent" />
        <div className="absolute left-4 top-4 flex gap-2">
          {profile.online && <span className="rounded-full bg-emerald-400 px-3 py-1 text-xs font-bold text-black">Online</span>}
          {profile.premium && <span className="rounded-full bg-yellow-300 px-3 py-1 text-xs font-bold text-black">Premium</span>}
        </div>
        <div className="absolute bottom-4 left-4 right-4">
          <div className="flex items-end justify-between gap-3">
            <div><h3 className="text-2xl font-black">{profile.name}, {profile.age}</h3><p className="mt-1 flex items-center gap-1 text-sm text-white/70">📍 {profile.city}, {profile.province}</p></div>
            {profile.verified && <span>🛡️</span>}
          </div>
        </div>
      </div>
      <div className="p-5">
        <p className="text-sm leading-6 text-white/65">{profile.bio}</p>
        <div className="mt-4 flex flex-wrap gap-2">{profile.interests.map((interest) => <span key={interest} className="rounded-full bg-white/10 px-3 py-1 text-xs text-white/75">{interest}</span>)}</div>
        <div className="mt-5 grid grid-cols-[1fr_auto_auto] gap-3">
          <button className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-fuchsia-500 to-violet-700 px-4 py-3 font-bold">💬 Mensaje</button>
          <button className="rounded-2xl bg-white/10 px-4 py-3 hover:bg-white/15">❤️</button>
          <button className="rounded-2xl bg-white/10 px-4 py-3 hover:bg-white/15">🚩</button>
        </div>
      </div>
    </article>
  );
}

function PremiumItem({ icon, text }) {
  return <div className="flex items-center gap-3 rounded-2xl bg-white/[0.06] p-4"><span className="text-fuchsia-200">{icon}</span><span className="font-semibold text-white/85">{text}</span></div>;
}

function SecurityCard({ icon, title, text }) {
  return <div className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6"><div className="mb-5 inline-flex rounded-2xl bg-white/10 p-3 text-fuchsia-200">{icon}</div><h3 className="text-xl font-black">{title}</h3><p className="mt-3 text-sm leading-6 text-white/55">{text}</p></div>;
}

function ActionButton({ icon, text }) {
  return <button className="flex items-center justify-center gap-2 rounded-2xl bg-white/10 px-4 py-3 font-bold hover:bg-white/15">{icon}{text}</button>;
}

function UploadCard({ icon, text }) {
  return <button className="flex min-h-32 flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/20 bg-white/[0.04] p-4 text-white/70 hover:bg-white/[0.07]"><span className="text-fuchsia-200">{icon}</span><span className="font-bold">{text}</span></button>;
}
